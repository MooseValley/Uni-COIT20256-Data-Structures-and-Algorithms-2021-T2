/*
Implement the Truck class that extends the Vehicle class. The Truck class should have the following members:
•	A field for the loading capacity in tonnage (a double).
•	A constructor and appropriate accessors and mutators.
•	A toString method that overrides the toString method in the superclass and displays relevant information on a Truck object.
 */
package w02vehiclecartruck;

/**
 *
 * @author omalleym
 */
public class Truck extends Vehicle
{
    private double loadingCapacity; // Tons
    
    public Truck()
    {
        this ("", "", 0.0, 0);
    }
    
    public Truck (String model, String yearMonth, double fuelEconomy, double loadingCapacity)
    {
        super (model, yearMonth, fuelEconomy); // Call Vehicle PC
        
        this.loadingCapacity = loadingCapacity;
    }
    
    public double getLoadingCapacity()
    {
        return loadingCapacity;
    }
    
    public void setLoadingCapacity(double loadingCapacity)
    {
        this.loadingCapacity = loadingCapacity;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + 
               String.format ("%8.2f", loadingCapacity);
    }
  
    
}
