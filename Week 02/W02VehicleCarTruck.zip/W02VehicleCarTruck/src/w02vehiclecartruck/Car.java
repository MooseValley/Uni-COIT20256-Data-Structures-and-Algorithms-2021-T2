/*
Implement the Car class that extends the Vehicle class. The Car class should have the following members:
•	A field for the maximum number of passenger (an int).
•	A constructor and appropriate accessors and mutators.
•	A toString method that overrides the toString method in the superclass and displays relevant information on a Car object.
 */
package w02vehiclecartruck;

/**
 *
 * @author omalleym
 */
public class Car extends Vehicle
{
    private int passengers;
    
    public Car()
    {
        this ("", "", 0.0, 0);
    }
    
    public Car (String model, String yearMonth, double fuelEconomy, int passengers)
    {
        super (model, yearMonth, fuelEconomy); // Call Vehicle PC
        
        this.passengers = passengers;
    }
    
    public int getPassengers()
    {
        return passengers;
    }
    
    public void setPassengers(int passengers)
    {
        this.passengers = passengers;
    }
    
    @Override
    public String toString()
    {
        return super.toString() + String.format ("%5d", passengers);
    }
    
}
