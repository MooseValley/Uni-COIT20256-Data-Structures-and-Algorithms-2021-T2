/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w02vehiclecartruck;

/**
 *
 * @author omalleym
 */
public class W02VehicleCarTruckTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        /*
        Vehicle v1 = new Vehicle();
        Vehicle v2 = new Vehicle("Toyota", "Jan-2010", 5.5);
        
        System.out.println (v2.getModel() + " fuel economy is " + 
                            v2.getFuelEconomy() + "Km/L");
    
        System.out.println (v1);
        System.out.println (v2.toString() );
        
        v1.setModel       ("Porche 911");
        v1.setYearMonth   ("Dec-1999");
        v1.setFuelEconomy (4.3);
        
        System.out.println (v1);
        System.out.println (v2.toString() );
        */
        
        Vehicle[] vehicles = new Vehicle [10];
        vehicles[0] = new Vehicle("Toyota",       "Jan-2010",  5.5);
        vehicles[1] = new Vehicle("Porche 911",   "Dec-1999",  4.3);
        vehicles[2] = new Vehicle("Ford Van",     "Oct-1994",  3.3);
        vehicles[3] = new Car    ("Ford Falcon",  "Oct-2004",  3.3,  4);
        vehicles[4] = new Car    ("Stretch Limo", "Jun-2021",  1.2, 16);
        vehicles[5] = new Truck  ("Kenworth",     "Apr-2015",  0.4, 30);
        vehicles[6] = new Truck  ("Tesla Truck",  "Apr-2015", 10.0, 40);


        
        for (int k = 0; k < vehicles.length; k++)
        {
            if (vehicles[k] != null)
                System.out.println (vehicles[k].toString() );
        }
        
        //for (Vehicle v : vehicles)
        //{
        //    System.out.println (v.toString() );
        //}

        double totalFuelEconomy = 0.0;
        int    count = 0;
        for (Vehicle v : vehicles)
        {
            if (v != null)
            {
                //totalFuelEconomy = totalFuelEconomy + v.getFuelEconomy();
                totalFuelEconomy += v.getFuelEconomy();
                //count = count + 1;
                count++;
            }
        }
        double avgFuelEconomy = 0.0;
        if (count > 0)
        {
            avgFuelEconomy = totalFuelEconomy / count; // vehicles.length;
        }
        System.out.println ("Avg Fuel Economy: " + 
                            String.format ("%.2f", avgFuelEconomy) );
            
     
        
        // Get Total Passengers
        int totalPassengers = 0;
        for (Vehicle v : vehicles)
        {
            if (v instanceof Car)
            {
                totalPassengers += ((Car) v).getPassengers();
            }
        }
        System.out.println ("Total Passengers: " + totalPassengers);
     
        
        
        // Typecasting
        int k = 5;
        double d = k; // All OK
        
        int k2 = (int) d;
        
        
        // Calculate the Average Loading Capcity
        
        
        // Calculate the Average Fuel Economy for all Cars and Vehicles (exclude Trucks).
        
    }
    
}
