/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricshapes;

/**
 *
 * @author omalleym
 */
public class GeometricShapesTester 
{
    
    // Circle
    public static double calculateArea(double radius)
    {
        return Math.PI * radius * radius;
    }
    
    // Rectangle
    public static double calculateArea(double length, double width)
    {
        return length * width;
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        System.out.println ("Area of Circle of radius 5.0: " + String.format ("%.2f", calculateArea (5.0)) );
        System.out.println ("Area of Rectangle 5.0 x 6.25: " + String.format ("%.2f", calculateArea (5.0, 6.25)) );
    }
    
}
