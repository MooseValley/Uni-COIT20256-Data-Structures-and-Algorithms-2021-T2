/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordchecker;

/**
 *
 * @author omalleym
 */
public class PasswordChecker 
{
    private String password;
    
    public PasswordChecker ()
    {
        this ("");
    }

    public PasswordChecker (String password)
    {
        this.password = password.trim(); // Assume we remove leading and trailing spaces ???
        
        isValid();
    }
    
    public boolean isValid()
    {
        boolean valid = false;  // Assume password is NOT valid and try and prove otherwise.
        int digitCount           = 0;
        int lowercaseLetterCount = 0;
        int uppercaseLetterCount = 0;
        
        if (password != null)
        {
            for (int k = 0; k < password.length(); k++)
            {
                if (Character.isDigit (password.charAt(k)) == true)
                {
                    digitCount++;
                }
                else if (Character.isLowerCase(password.charAt(k)) == true)
                {
                    lowercaseLetterCount++;
                }
                else if (Character.isUpperCase(password.charAt(k)) == true)
                {
                    uppercaseLetterCount++;
                }
            }
            
            if ((password.length()    >= 8) &&
                (digitCount           >= 1) && 
                (lowercaseLetterCount >= 1) && 
                (uppercaseLetterCount >= 1) )
            {
                valid = true; // Password is valid.
            }
        }

        if (valid == true)
            System.out.println ("Password: '" + password + "' is valid.");
        else
            System.out.println ("Password: '" + password + "' is NOT valid.");

        return valid;
    }


}
