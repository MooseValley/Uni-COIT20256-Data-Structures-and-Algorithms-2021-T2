/*
Question 5
Write a Java application that checks whether a password input is valid or not. The criteria for a valid password are as follows. 
(i) The password must have at least one digit.
(ii) The password must contain at least one lowercase letter and at least one uppercase letter. 
(iii) The password length must contain at least eight characters. 

You can implement this program with a class named PasswordChecker, 
which has a data member - password (a String) and a method to verify the validity of the password. 

Note: Refer to Regular expressions from Introduction to Programing.

 */
package passwordchecker;

/**
 *
 * @author omalleym
 */
public class PasswordCheckerTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        PasswordChecker pw1 = new PasswordChecker ("123Am");
        PasswordChecker pw2 = new PasswordChecker ("123A");
        PasswordChecker pw3 = new PasswordChecker ("123Aa8MM");
        PasswordChecker pw4 = new PasswordChecker ("123Abvcx");
    }
    
}
