package flowers;

/**
 *
 * @author omalleym
 * 
 * *** Students TODO
 * In this exercise you are also required to include validation checks in the set methods 
 * i.e. a flower name should not be null and should only contain alphabetical characters. 
 * 
 */
public class Flower 
{
    private static final String UNKNOWN_NAME__STR    = "unknown";
    private static final String UNKNOWN_CATEGORY_STR = "unknown";
    private static final double UNKNOWN_PRICE        = 0.0;

    private static int count = 0; // Count of how many flower objects have been created.
    
    private String name;
    private String category;
    private double price;

    // Default Constructor
    public Flower()
    {
        this (UNKNOWN_NAME__STR, UNKNOWN_CATEGORY_STR, UNKNOWN_PRICE); // Call Parameterised Constructor #1
    }
    
    // Parameterised Constructor #1
    public Flower(String name, String category, double price)
    {
        this.name     = name;
        this.category = category;
        this.price    = price;
        
        count++; 
    }
    
    // Parameterised Constructor #2
    public Flower(String name, String category)
    {
        this (name, category, UNKNOWN_PRICE); // Call Parameterised Constructor #1
    }

    // Parameterised Constructor #3
    public Flower(String name)
    {
        this (name, UNKNOWN_CATEGORY_STR, UNKNOWN_PRICE); // Call Parameterised Constructor #1
    }

    
    // Accessors

    public String getName() 
    {
        return name;
    }

    public String getCategory() 
    {
        return category;
    }

    public double getPrice() {
        return price;
    }
    
    public static int getCount()
    {
        return count;
    }

    
    // Mutators
    
    public void setName(String name) 
    {
        this.name = name;
    }

    public void setCategory(String category) 
    {
        this.category = category;
    }

    public void setPrice(double price) 
    {
        this.price = price;
    }

    @Override
    public String toString()
    {
        return "< " + name + " " + category + " $" + String.format ("%.2f", price) + " >";
    }
    
}
