/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flowers;

/**
 *
 * @author omalleym
 */
public class FlowersTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println ("The number of flowers is now: " + Flower.getCount() );
        
        Flower flow1 = new Flower("daisy", "filler", 2.0);
        Flower flow2 = new Flower();
        
        System.out.println (flow1);
        System.out.println (flow2);
        
        System.out.println ("The number of flowers is now: " + Flower.getCount() );

        Flower flow3 = new Flower("rose", "focal");
        Flower flow4 = new Flower("snap dragon");

        System.out.println (flow3);
        System.out.println (flow4);

        System.out.println ("The number of flowers is now: " + Flower.getCount() );
    }
    
}
