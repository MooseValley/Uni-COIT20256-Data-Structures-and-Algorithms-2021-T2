/**


Programming exercise
*/

import javax.swing.JOptionPane;


public class CalCircleArea
{

   //main method
   public static void main(String[] args)
   {
        
        
         Scanner input = new Scanner(System.in);
         System.out.print("Enter the radius: ");
         
         double radius = input.nextDouble();

         double area=circleArea(radius);
         
         System.out.printf("The area is %.2f%n", area);
         
         

   }

   public static double circleArea(double radius)
   {
		return Math.PI * radius * radius;
   }


}
