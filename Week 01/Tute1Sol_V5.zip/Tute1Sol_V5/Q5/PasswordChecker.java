/**

Check whether password meets the criteria as set- valid or invalid
Programming exercise
*/

import javax.swing.JOptionPane;

public class PasswordChecker
{

   private String myPassword;
   private static final int MIN_PASSWORD_LENGTH = 8; // Assumed minimum password length is 8

   public PasswordChecker(String inputPassword)
   {

	   myPassword=inputPassword;
   }


   // isValid method determines whether a password is
   public boolean isValid( )
   {
      boolean status;   // Flag

      if (myPassword.length() >= MIN_PASSWORD_LENGTH && hasUpperCase(myPassword) &&
          hasLowerCase(myPassword) && hasDigit(myPassword))
         status = true;
      else
         status = false;

      return status;
   }

   /**
      The hasUpperCase method determines whether a string
      has at least one uppercase character.
   */

   private boolean hasUpperCase(String str)
   {
      boolean status = false; // Flag

      for (int i = 0; i < str.length(); i++)
      {
         if (Character.isUpperCase(str.charAt(i)))
            status = true;
      }

      return status;
   }

   /**
      The hasLowerCase method determines whether a string
      has at least one lowercase character.
   */

   private boolean hasLowerCase(String str)
   {
      boolean status = false;

      for (int i = 0; i < str.length(); i++)
      {
         if (Character.isLowerCase(str.charAt(i)))
            status = true;
      }

      return status;
   }

   /**
      The hasDigit method determines whether a string
      has at least one numeric digit.
   */

   private boolean hasDigit(String str)
   {
      boolean status = false;

      for (int i = 0; i < str.length(); i++)
      {
         if (Character.isDigit(str.charAt(i)))
            status = true;
      }

      return status;
   }

   //main method
   public static void main(String[] args)
   {
         String inputPassword;  // keyboard password input string

         

         // Get a password string.
         System.out.print("Please enter password: ");
         Scanner input = new Scanner(System.in);
         inputPassword = input.next();

         PasswordChecker pw=new PasswordChecker(inputPassword);


         // Determine whether the password is valid or not.
         if (!pw.isValid())
             System.out.println("   Invalid password");
         else
             System.out.println("   Valid password");

         // Exit the applicaton.
         System.exit(0);
   }


}
