AreaDemo//demo of method overloading


public class AreaDemo
{
	public static void main(String[] args)
	{
		// Get the area of a circle with a radius of 20.0.
		System.out.println("The area of a circle with a " +
		                   "radius of 20.0 is " +
								 Area.getArea(20.0)+"\n");

		// Get the area of a rectangle with a length of 10
		// and a width of 20.
		System.out.println("The area of a rectangle with a " +
		                   "length of 10 and a width of 20 is " +
								 Area.getArea(10, 20));

	}
}
