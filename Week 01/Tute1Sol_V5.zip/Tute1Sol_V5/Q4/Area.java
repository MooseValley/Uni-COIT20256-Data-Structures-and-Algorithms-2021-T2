

public class Area
{
	//circle area with the radius as parameter
    public static double getArea(double radius)
	{
		return Math.PI * radius * radius;
	}

	/** This getArea method returns the area of a
		rectangle.@param length The rectangle's length.
		@param width The rectangle's width.
	*/

	public static double getArea(int length, int width)
	{
		return length * width;
	}


}
